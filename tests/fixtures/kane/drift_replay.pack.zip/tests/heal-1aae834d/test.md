---
mode: testing
max_steps: 15
url: http://localhost:5000
---

# Heal probe

## c09
Store the exact visible text of the heading, label, button or message on the page that is closest to "Hello, World!" as 'c09_label'. Verify the page has finished loading.
