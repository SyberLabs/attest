---
mode: testing
max_steps: 15
url: http://localhost:5000
---

# Smoke

## c07
Check that the page shows the text "Hello, World!" and store the exact visible text of the greeting as 'c07_label'.
