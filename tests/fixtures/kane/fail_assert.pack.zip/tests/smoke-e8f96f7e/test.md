---
mode: testing
max_steps: 15
url: http://localhost:5000
---

# Smoke

## c07
Check that the page shows the text "Hello, World!" and store the exact visible text of the greeting as 'c07_label'.

## c08
Store the exact visible text of the element the doc calls "Goodbye, World!" as 'c08_label'. If that exact text is not on the page, store the text of the closest matching heading, label, button or message instead. Store what the page shows now and do not wait for it to change. Verify that element is visible.
