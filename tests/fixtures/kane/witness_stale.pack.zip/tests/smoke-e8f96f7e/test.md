---
mode: testing
max_steps: 15
url: http://localhost:5000
---

# Smoke

## c07
Check that the page shows the text "Hello, World!" and store the exact visible text of the greeting as 'c07_label'.

## c08
Store the exact visible text of the heading, label, button or message on the page that is closest to "Goodbye, World!" as 'c08_label'. Verify the page has finished loading.
